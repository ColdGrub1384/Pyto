//
//  ios_flang_runtime.h
//  ios_flang_runtime
//
//  Created by Emma Labbé on 30-11-20.
//

#import <Foundation/Foundation.h>

//! Project version number for ios_flang_runtime.
FOUNDATION_EXPORT double ios_flang_runtimeVersionNumber;

//! Project version string for ios_flang_runtime.
FOUNDATION_EXPORT const unsigned char ios_flang_runtimeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ios_flang_runtime/PublicHeader.h>


